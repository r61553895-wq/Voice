# Keep AI model interfaces / reflection-based inference entry points
-keep class com.voicechanger.app.ai_model.** { *; }
-keep class com.voicechanger.app.audio_engine.** { *; }

# ONNX Runtime / TFLite (uncomment if enabled)
# -keep class ai.onnxruntime.** { *; }
# -keep class org.tensorflow.** { *; }
