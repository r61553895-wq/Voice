package com.voicechanger.app

import com.voicechanger.app.audio_engine.dsp.PitchShifter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin
import kotlin.math.PI

class PitchShifterTest {

    @Test
    fun `output frame length matches input frame length`() {
        val shifter = PitchShifter(grainSize = 480)
        val input = FloatArray(960) { i -> sin(2.0 * PI * 220.0 * i / 48000.0).toFloat() }
        val output = FloatArray(960)

        shifter.process(input, output, pitchRatio = 1.5f)

        assertEquals(input.size, output.size)
    }

    @Test
    fun `output stays within valid audio range`() {
        val shifter = PitchShifter(grainSize = 480)
        val input = FloatArray(960) { i -> sin(2.0 * PI * 440.0 * i / 48000.0).toFloat() }
        val output = FloatArray(960)

        repeat(20) { shifter.process(input, output, pitchRatio = 0.7f) }

        assertTrue(output.all { it in -1.5f..1.5f })
    }

    @Test
    fun `pitch ratio of 1 is close to passthrough after settling`() {
        val shifter = PitchShifter(grainSize = 480)
        val input = FloatArray(960) { i -> sin(2.0 * PI * 300.0 * i / 48000.0).toFloat() }
        val output = FloatArray(960)

        // Run a few frames to let the crossfade state settle.
        repeat(5) { shifter.process(input, output, pitchRatio = 1.0f) }

        val rmsIn = Math.sqrt(input.sumOf { (it * it).toDouble() } / input.size)
        val rmsOut = Math.sqrt(output.sumOf { (it * it).toDouble() } / output.size)

        assertTrue(Math.abs(rmsIn - rmsOut) < 0.3)
    }
}
