package com.voicechanger.app.domain.model

sealed class EngineState {
    data object Idle : EngineState()
    data object Starting : EngineState()
    data class Running(val inputLevel: Float, val latencyMs: Int) : EngineState()
    data class Error(val message: String) : EngineState()
}

/** Which processing backend is actually converting the voice. */
enum class ProcessingMode {
    /** Pure passthrough — used to validate the mic → speaker pipeline with no changes. */
    TEST_PASSTHROUGH,
    /** Classic DSP chain (pitch/formant/robot/reverb/echo). */
    DSP,
    /** Neural voice conversion (ONNX / TFLite / RVC). Falls back to DSP if no model is loaded. */
    AI_MODEL
}
