package com.voicechanger.app.di

import com.voicechanger.app.data.repository.AudioEngineRepositoryImpl
import com.voicechanger.app.domain.repository.AudioEngineRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModule {

    @Binds
    abstract fun bindAudioEngineRepository(
        impl: AudioEngineRepositoryImpl
    ): AudioEngineRepository
}
