package com.voicechanger.app.domain.usecase

import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.model.VoicePreset
import com.voicechanger.app.domain.repository.AudioEngineRepository
import javax.inject.Inject

class SelectVoicePresetUseCase @Inject constructor(
    private val repository: AudioEngineRepository
) {
    /** Returns the resolved settings so the ViewModel/UI can reflect them in the sliders. */
    operator fun invoke(preset: VoicePreset): EffectSettings {
        val settings = preset.toDefaultSettings()
        repository.updateEffectSettings(settings)
        return settings
    }
}
