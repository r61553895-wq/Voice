package com.voicechanger.app.domain.usecase

import com.voicechanger.app.domain.model.ProcessingMode
import com.voicechanger.app.domain.repository.AudioEngineRepository
import javax.inject.Inject

class StartVoiceChangerUseCase @Inject constructor(
    private val repository: AudioEngineRepository
) {
    operator fun invoke(mode: ProcessingMode = ProcessingMode.DSP) {
        repository.start(mode)
    }
}
