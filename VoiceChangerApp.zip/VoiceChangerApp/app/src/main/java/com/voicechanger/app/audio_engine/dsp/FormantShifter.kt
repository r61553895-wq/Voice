package com.voicechanger.app.audio_engine.dsp

/**
 * Lightweight "formant" / timbre control.
 *
 * True formant shifting requires estimating and warping the vocal-tract spectral envelope
 * (LPC or cepstral liftering) independently of pitch. That's out of scope for a
 * dependency-free MVP DSP chain, so this implements a cheap-but-effective approximation:
 * a pair of one-pole shelving filters that darken (negative formant -> "bigger"/deeper
 * body) or brighten (positive formant -> "smaller"/female-ish body) the timbre.
 *
 * For accurate formant-preserving pitch shift or full timbre conversion, swap this stage
 * out for an AI model (see ai_model/) — that's exactly the kind of transformation neural
 * voice conversion (e.g. RVC) is good at.
 */
class FormantShifter(private val sampleRate: Int) {

    private var lowShelfState = 0f
    private var highShelfState = 0f

    fun reset() {
        lowShelfState = 0f
        highShelfState = 0f
    }

    /** `formant` in [-1, 1]. 0 = no coloration. */
    fun process(input: FloatArray, output: FloatArray, formant: Float) {
        val amount = formant.coerceIn(-1f, 1f)

        // One-pole low-pass used as the smoothing element for both shelves.
        val cutoffHz = if (amount < 0) 900f else 2600f
        val a = onePoleCoefficient(cutoffHz)

        for (i in input.indices) {
            val x = input[i]

            lowShelfState += a * (x - lowShelfState)
            val low = lowShelfState

            highShelfState += a * (x - highShelfState)
            val high = x - highShelfState // high-passed component

            output[i] = when {
                amount < 0f -> {
                    // Darken: boost low band, gently attenuate high band.
                    val g = -amount
                    x + g * low * 0.6f - g * high * 0.3f
                }
                amount > 0f -> {
                    // Brighten: boost high band, gently attenuate low band.
                    val g = amount
                    x + g * high * 0.7f - g * low * 0.25f
                }
                else -> x
            }
        }
    }

    private fun onePoleCoefficient(cutoffHz: Float): Float {
        val rc = 1.0 / (2.0 * Math.PI * cutoffHz)
        val dt = 1.0 / sampleRate
        return (dt / (rc + dt)).toFloat()
    }
}
