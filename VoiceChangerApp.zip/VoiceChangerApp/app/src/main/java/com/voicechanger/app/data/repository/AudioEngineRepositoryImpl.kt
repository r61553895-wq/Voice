package com.voicechanger.app.data.repository

import android.content.Context
import android.content.Intent
import com.voicechanger.app.audio_engine.AudioEngine
import com.voicechanger.app.audio_engine.service.VoiceChangerService
import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.model.EngineState
import com.voicechanger.app.domain.model.ProcessingMode
import com.voicechanger.app.domain.repository.AudioEngineRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AudioEngineRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val audioEngine: AudioEngine
) : AudioEngineRepository {

    override val engineState: StateFlow<EngineState> = audioEngine.state

    override fun start(mode: ProcessingMode) {
        audioEngine.setMode(mode)
        val intent = Intent(context, VoiceChangerService::class.java).apply {
            putExtra(VoiceChangerService.EXTRA_MODE, mode.name)
        }
        context.startForegroundService(intent)
    }

    override fun stop() {
        context.stopService(Intent(context, VoiceChangerService::class.java))
    }

    override fun updateEffectSettings(settings: EffectSettings) {
        audioEngine.updateSettings(settings)
    }

    override fun setProcessingMode(mode: ProcessingMode) {
        audioEngine.setMode(mode)
    }

    override fun isRunning(): Boolean = audioEngine.isRunning()
}
