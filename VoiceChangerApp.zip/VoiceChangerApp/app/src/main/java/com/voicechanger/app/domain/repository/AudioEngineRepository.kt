package com.voicechanger.app.domain.repository

import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.model.EngineState
import com.voicechanger.app.domain.model.ProcessingMode
import kotlinx.coroutines.flow.StateFlow

/**
 * Abstraction the domain/presentation layers use to control the real-time audio engine.
 * The concrete implementation lives in `data` and delegates to `audio_engine`.
 */
interface AudioEngineRepository {

    val engineState: StateFlow<EngineState>

    /** Starts capturing the mic, processing it, and playing it back through the speaker/headset. */
    fun start(mode: ProcessingMode)

    fun stop()

    fun updateEffectSettings(settings: EffectSettings)

    fun setProcessingMode(mode: ProcessingMode)

    fun isRunning(): Boolean
}
