package com.voicechanger.app.ai_model

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The single place the rest of the app talks to when it wants "the AI model".
 *
 * *** THIS IS THE SWAP POINT ***
 * To plug in a real ONNX/TFLite/RVC model:
 *   1. Copy one of the templates from /ai_model_templates into this package.
 *   2. Uncomment its dependency in app/build.gradle.kts.
 *   3. Replace `currentModel = NoOpVoiceModel()` below with your implementation, e.g.
 *        currentModel = OnnxVoiceModel(frameSize = AudioConfig.FRAME_SIZE)
 *   4. Call [loadModel] with the path to your exported model file (e.g. copied from
 *      assets into `context.filesDir` on first launch).
 *
 * No other class in audio_engine/, domain/, or presentation/ needs to change.
 */
@Singleton
class AiModelManager @Inject constructor(
    private val context: Context
) {
    private var currentModel: AiVoiceModel = NoOpVoiceModel()

    fun currentModel(): AiVoiceModel = currentModel

    suspend fun loadModel(assetOrFilePath: String): Boolean = withContext(Dispatchers.IO) {
        val file = File(assetOrFilePath)
        if (!file.exists()) return@withContext false
        currentModel.load(file.absolutePath)
    }

    fun unload() {
        currentModel.unload()
    }

    fun isModelReady(): Boolean = currentModel.isLoaded() && currentModel.isRealtimeCapable
}
