package com.voicechanger.app.audio_engine.dsp

import kotlin.math.sin
import kotlin.math.PI

/**
 * Classic "robot voice" via ring modulation: multiplying the signal by a fixed-frequency
 * carrier sine creates the metallic, monotone-pitched buzz associated with vocoders/robots.
 */
class RobotEffect(private val sampleRate: Int, private val carrierHz: Float = 55f) {

    private var phase = 0.0

    fun reset() {
        phase = 0.0
    }

    /** `amount` in [0, 1]. 0 = untouched voice, 1 = fully ring-modulated. */
    fun process(input: FloatArray, output: FloatArray, amount: Float) {
        val mix = amount.coerceIn(0f, 1f)
        if (mix <= 0f) {
            input.copyInto(output)
            return
        }
        val phaseInc = 2.0 * PI * carrierHz / sampleRate
        for (i in input.indices) {
            val carrier = sin(phase).toFloat()
            phase += phaseInc
            if (phase > 2.0 * PI) phase -= 2.0 * PI

            val modulated = input[i] * carrier
            output[i] = input[i] * (1 - mix) + modulated * mix
        }
    }
}
