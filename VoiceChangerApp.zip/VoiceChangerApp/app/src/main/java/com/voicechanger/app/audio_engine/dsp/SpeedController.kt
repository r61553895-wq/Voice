package com.voicechanger.app.audio_engine.dsp

/**
 * Changes talking speed (and, as a side effect, pitch slightly — like a tape speed change)
 * by resampling into an internal FIFO. Because speed changes the *amount* of audio produced
 * per input frame, we decouple "how much we resample per call" from "how much we hand back
 * to the fixed-size audio callback" using a small ring FIFO. This keeps AudioTrack writes at
 * a constant frame size regardless of the speed setting.
 *
 * Kept intentionally small (a few frames) so it cannot introduce more than a few ms of
 * extra latency; if it underruns we pad with the last sample, if it overruns we drop the
 * oldest samples rather than let latency grow unbounded.
 */
class SpeedController(maxFifoSamples: Int) {

    private val fifo = FloatArray(maxFifoSamples)
    private var readPos = 0
    private var writePos = 0
    private var available = 0
    private val capacity = maxFifoSamples
    private var lastSample = 0f

    fun reset() {
        fifo.fill(0f)
        readPos = 0
        writePos = 0
        available = 0
        lastSample = 0f
    }

    /** Resamples [input] by `1/speed` and pushes the result into the FIFO. */
    fun push(input: FloatArray, speed: Float) {
        val s = speed.coerceIn(0.5f, 1.5f)
        if (s == 1.0f) {
            for (v in input) writeOne(v)
            return
        }
        var pos = 0f
        while (pos < input.size - 1) {
            val i0 = pos.toInt()
            val frac = pos - i0
            val v = input[i0] * (1 - frac) + input[i0 + 1] * frac
            writeOne(v)
            pos += s
        }
    }

    /** Pops exactly [count] samples (padding with the last known sample on underrun). */
    fun pop(count: Int, out: FloatArray) {
        for (i in 0 until count) {
            if (available > 0) {
                out[i] = fifo[readPos]
                lastSample = out[i]
                readPos = (readPos + 1) % capacity
                available--
            } else {
                out[i] = lastSample * 0.98f // gentle decay instead of hard silence on underrun
                lastSample = out[i]
            }
        }
    }

    private fun writeOne(v: Float) {
        if (available >= capacity) {
            // Overrun: drop oldest sample to keep latency bounded.
            readPos = (readPos + 1) % capacity
            available--
        }
        fifo[writePos] = v
        writePos = (writePos + 1) % capacity
        available++
    }
}
