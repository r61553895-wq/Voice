package com.voicechanger.app.domain.model

/**
 * All tunable DSP parameters. Values are UI-friendly (not raw DSP coefficients) —
 * the audio engine is responsible for translating these into filter/algorithm parameters.
 */
data class EffectSettings(
    /** -12..+12 semitones. Negative = deeper, positive = higher pitched. */
    val pitchSemitones: Float = 0f,
    /** -1.0..+1.0 timbre shift. Negative = darker/bigger, positive = brighter/smaller vocal tract. */
    val formant: Float = 0f,
    /** 0.5..1.5 playback/talking speed multiplier. */
    val speed: Float = 1.0f,
    /** 0.0..1.0 amount of ring-modulation "robot" effect. */
    val robotAmount: Float = 0f,
    /** 0.0..1.0 wet mix of the reverb send. */
    val reverbMix: Float = 0f,
    /** 0.0..1.0 wet mix of the echo/delay send. */
    val echoMix: Float = 0f
)
