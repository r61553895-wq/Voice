package com.voicechanger.app.audio_engine.dsp

import com.voicechanger.app.audio_engine.AudioConfig

/** Simple feedback delay line for an echo effect. */
class EchoEffect(private val sampleRate: Int, private val delayMs: Int = 220) {

    private val buffer = FloatArray((sampleRate * AudioConfig.MAX_ECHO_DELAY_MS / 1000f).toInt())
    private var index = 0
    private val delaySamples = (sampleRate * delayMs / 1000f).toInt().coerceIn(1, buffer.size - 1)

    fun reset() {
        buffer.fill(0f)
        index = 0
    }

    /** `mix` in [0, 1] wet amount; feedback fixed at a musical 35%. */
    fun process(input: FloatArray, output: FloatArray, mix: Float) {
        val wet = mix.coerceIn(0f, 1f)
        if (wet <= 0f) {
            input.copyInto(output)
            return
        }
        val feedback = 0.35f
        for (i in input.indices) {
            val readIdx = (index - delaySamples + buffer.size) % buffer.size
            val delayed = buffer[readIdx]
            val dry = input[i]

            buffer[index] = dry + delayed * feedback
            index = (index + 1) % buffer.size

            output[i] = dry * (1 - wet) + delayed * wet
        }
    }
}
