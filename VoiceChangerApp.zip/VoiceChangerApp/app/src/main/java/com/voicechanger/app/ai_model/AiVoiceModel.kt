package com.voicechanger.app.ai_model

/**
 * Contract every neural voice-conversion backend must implement (RVC, a custom ONNX export,
 * TFLite, etc). Implementations are swappable at runtime through [AiModelManager] without
 * touching the audio engine or UI — that's the whole point of this abstraction.
 *
 * Implementations MUST be non-blocking-fast: [convert] runs on the real-time audio thread
 * budget (a single frame is ~20 ms @ 48kHz). If your model can't keep up in real time on
 * device, run it on a coarser hop size with internal buffering/threading and report
 * [isRealtimeCapable] = false so the engine can fall back to the DSP chain automatically.
 */
interface AiVoiceModel {

    /** Human-readable name shown in diagnostics/logs. */
    val name: String

    /** Sample rate this model expects as input (engine will resample if it differs). */
    val requiredSampleRate: Int

    /** Whether this implementation has measured itself fast enough for live mic input. */
    val isRealtimeCapable: Boolean

    /** Loads weights/graph from [modelPath] (e.g. an .onnx or .tflite file in app storage). */
    suspend fun load(modelPath: String): Boolean

    /** Frees native resources. Must be safe to call multiple times. */
    fun unload()

    /**
     * Converts one frame of mono float PCM (-1..1) into the target voice.
     * Input and output lengths may differ if your model uses internal buffering —
     * the caller handles resizing via an internal FIFO, mirroring [com.voicechanger.app.audio_engine.dsp.SpeedController].
     */
    fun convert(inputFrame: FloatArray): FloatArray

    fun isLoaded(): Boolean
}
