package com.voicechanger.app.audio_engine

/**
 * Central place for all audio format / buffering constants.
 *
 * Frame size directly trades off latency vs. processing quality/stability:
 *   - Smaller frames  -> lower latency, more per-block overhead, less context for DSP.
 *   - Larger frames    -> higher latency, smoother pitch/formant processing.
 *
 * 20 ms @ 48 kHz = 960 samples. Two frames of look-ahead/overlap keep total
 * mic -> speaker latency in the ~40-90 ms range on most devices (well within the <100ms target),
 * though actual end-to-end latency also depends on the device's HAL/driver buffering.
 */
object AudioConfig {
    const val SAMPLE_RATE = 48_000
    const val CHANNELS_MONO = 1

    /** Samples per processing frame (~20 ms at 48kHz). */
    const val FRAME_SIZE = 960

    /** Internal DSP grain size used by the pitch shifter (must divide evenly for overlap-add). */
    const val GRAIN_SIZE = 480
    const val GRAIN_OVERLAP = GRAIN_SIZE / 2

    /** Number of frames buffered internally; keep small for low latency. */
    const val BUFFER_FRAMES = 4

    const val MAX_ECHO_DELAY_MS = 350
    const val MAX_REVERB_TAIL_MS = 400
}
