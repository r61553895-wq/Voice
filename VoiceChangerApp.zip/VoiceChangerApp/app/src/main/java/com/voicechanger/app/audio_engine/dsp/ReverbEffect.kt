package com.voicechanger.app.audio_engine.dsp

/**
 * Classic Schroeder reverb: 4 parallel feedback comb filters summed, feeding 2 series
 * all-pass filters for diffusion. Mono in/out, tuned for 48kHz.
 */
class ReverbEffect(private val sampleRate: Int) {

    private class Comb(delayMs: Float, private val feedback: Float, sampleRate: Int) {
        private val buffer = FloatArray((sampleRate * delayMs / 1000f).toInt().coerceAtLeast(1))
        private var index = 0
        fun process(x: Float): Float {
            val y = buffer[index]
            buffer[index] = x + y * feedback
            index = (index + 1) % buffer.size
            return y
        }
        fun reset() { buffer.fill(0f); index = 0 }
    }

    private class AllPass(delayMs: Float, private val g: Float, sampleRate: Int) {
        private val buffer = FloatArray((sampleRate * delayMs / 1000f).toInt().coerceAtLeast(1))
        private var index = 0
        fun process(x: Float): Float {
            val bufOut = buffer[index]
            val y = -g * x + bufOut
            buffer[index] = x + bufOut * g
            index = (index + 1) % buffer.size
            return y
        }
        fun reset() { buffer.fill(0f); index = 0 }
    }

    private val combs = listOf(
        Comb(29.7f, 0.77f, sampleRate),
        Comb(37.1f, 0.74f, sampleRate),
        Comb(41.1f, 0.71f, sampleRate),
        Comb(43.7f, 0.68f, sampleRate)
    )
    private val allPasses = listOf(
        AllPass(5.0f, 0.5f, sampleRate),
        AllPass(1.7f, 0.5f, sampleRate)
    )

    fun reset() {
        combs.forEach { it.reset() }
        allPasses.forEach { it.reset() }
    }

    /** `mix` in [0, 1] wet amount. */
    fun process(input: FloatArray, output: FloatArray, mix: Float) {
        val wet = mix.coerceIn(0f, 1f)
        if (wet <= 0f) {
            input.copyInto(output)
            return
        }
        for (i in input.indices) {
            val dry = input[i]
            var combSum = 0f
            for (c in combs) combSum += c.process(dry)
            combSum *= 0.25f

            var diffused = combSum
            for (ap in allPasses) diffused = ap.process(diffused)

            output[i] = dry * (1 - wet) + diffused * wet
        }
    }
}
