package com.voicechanger.app.presentation.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.voicechanger.app.domain.model.VoicePreset

private fun iconFor(preset: VoicePreset): ImageVector = when (preset) {
    VoicePreset.NORMAL -> Icons.Filled.Person
    VoicePreset.DEEP -> Icons.Filled.Whatshot
    VoicePreset.FEMALE -> Icons.Filled.Mood
    VoicePreset.ROBOT -> Icons.Filled.SmartToy
    VoicePreset.MONSTER -> Icons.Filled.Face
    VoicePreset.ANIME -> Icons.Filled.SentimentSatisfied
}

@Composable
fun VoicePresetSelector(
    selected: VoicePreset,
    onSelect: (VoicePreset) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        items(VoicePreset.values().toList()) { preset ->
            PresetChip(preset = preset, isSelected = preset == selected, onClick = { onSelect(preset) })
        }
    }
}

@Composable
private fun PresetChip(preset: VoicePreset, isSelected: Boolean, onClick: () -> Unit) {
    val bg = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val fg = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = bg,
        onClick = onClick,
        modifier = Modifier
    ) {
        androidx.compose.foundation.layout.Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Icon(imageVector = iconFor(preset), contentDescription = null, tint = fg)
            Text(text = preset.displayName, color = fg, style = MaterialTheme.typography.labelSmall)
        }
    }
}
