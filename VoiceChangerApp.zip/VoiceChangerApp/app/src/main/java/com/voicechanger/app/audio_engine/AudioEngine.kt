package com.voicechanger.app.audio_engine

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import android.util.Log
import com.voicechanger.app.ai_model.AiModelManager
import com.voicechanger.app.audio_engine.dsp.DspChain
import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.model.EngineState
import com.voicechanger.app.domain.model.ProcessingMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * Owns the real-time mic -> process -> speaker loop. Runs entirely on a dedicated
 * high-priority thread (THREAD_PRIORITY_URGENT_AUDIO) to keep latency low and predictable;
 * never call its methods from the main thread except start()/stop() themselves.
 */
@Singleton
class AudioEngine @Inject constructor(
    private val aiModelManager: AiModelManager
) {
    private val _state = MutableStateFlow<EngineState>(EngineState.Idle)
    val state: StateFlow<EngineState> = _state

    private val settingsRef = AtomicReference(EffectSettings())
    private val modeRef = AtomicReference(ProcessingMode.DSP)

    @Volatile private var running = false
    private var audioThread: Thread? = null

    fun updateSettings(settings: EffectSettings) {
        settingsRef.set(settings)
    }

    fun setMode(mode: ProcessingMode) {
        modeRef.set(mode)
    }

    fun isRunning(): Boolean = running

    @SuppressLint("MissingPermission") // caller (ViewModel/Service) verifies RECORD_AUDIO first
    fun start() {
        if (running) return
        running = true
        _state.update { EngineState.Starting }

        audioThread = thread(
            start = true,
            name = "AudioEngineThread",
            priority = Thread.MAX_PRIORITY
        ) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            runAudioLoop()
        }
    }

    fun stop() {
        running = false
        audioThread?.join(500)
        audioThread = null
        _state.update { EngineState.Idle }
    }

    private fun runAudioLoop() {
        val sampleRate = AudioConfig.SAMPLE_RATE
        val frameSize = AudioConfig.FRAME_SIZE

        val minRecordBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minTrackBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minRecordBuf <= 0 || minTrackBuf <= 0) {
            _state.update { EngineState.Error("Device does not support required audio format") }
            running = false
            return
        }

        val recordBufSize = maxOf(minRecordBuf, frameSize * 2 * AudioConfig.BUFFER_FRAMES)
        val trackBufSize = maxOf(minTrackBuf, frameSize * 2 * AudioConfig.BUFFER_FRAMES)

        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, // enables device AEC/NS where available
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            recordBufSize
        )

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(trackBufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                }
            }
            .build()

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
            _state.update { EngineState.Error("Failed to initialize AudioRecord") }
            running = false
            return
        }

        val dspChain = DspChain(sampleRate, frameSize)
        val shortIn = ShortArray(frameSize)
        val floatIn = FloatArray(frameSize)
        val floatOut = FloatArray(frameSize)
        val shortOut = ShortArray(frameSize)

        try {
            audioRecord.startRecording()
            audioTrack.play()
            _state.update { EngineState.Running(inputLevel = 0f, latencyMs = estimateLatencyMs(recordBufSize, trackBufSize, sampleRate)) }

            while (running) {
                val read = audioRecord.read(shortIn, 0, frameSize)
                if (read <= 0) continue

                // PCM16 -> float [-1, 1]
                var peak = 0f
                for (i in 0 until read) {
                    val f = shortIn[i] / 32768f
                    floatIn[i] = f
                    val a = abs(f)
                    if (a > peak) peak = a
                }

                val settings = settingsRef.get()
                when (modeRef.get()) {
                    ProcessingMode.TEST_PASSTHROUGH -> floatIn.copyInto(floatOut, 0, 0, read)
                    ProcessingMode.DSP -> {
                        dspChain.process(floatIn, settings)
                        dspChain.speedController.pop(read, floatOut)
                    }
                    ProcessingMode.AI_MODEL -> {
                        val model = aiModelManager.currentModel()
                        if (aiModelManager.isModelReady()) {
                            val converted = model.convert(floatIn.copyOf(read))
                            converted.copyInto(floatOut, 0, 0, minOf(converted.size, read))
                        } else {
                            // Graceful fallback: no AI model loaded yet -> use DSP chain.
                            dspChain.process(floatIn, settings)
                            dspChain.speedController.pop(read, floatOut)
                        }
                    }
                }

                // float -> PCM16
                for (i in 0 until read) {
                    val clamped = floatOut[i].coerceIn(-1f, 1f)
                    shortOut[i] = (clamped * 32767f).toInt().toShort()
                }

                audioTrack.write(shortOut, 0, read)

                _state.update { current ->
                    if (current is EngineState.Running) current.copy(inputLevel = peak) else current
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Audio loop error", t)
            _state.update { EngineState.Error(t.message ?: "Unknown audio error") }
        } finally {
            runCatching { audioRecord.stop() }
            runCatching { audioRecord.release() }
            runCatching { audioTrack.stop() }
            runCatching { audioTrack.release() }
        }
    }

    private fun estimateLatencyMs(recordBuf: Int, trackBuf: Int, sampleRate: Int): Int {
        val totalBytes = recordBuf + trackBuf
        val samples = totalBytes / 2 // 16-bit
        return (samples * 1000L / sampleRate).toInt()
    }

    companion object {
        private const val TAG = "AudioEngine"
    }
}
