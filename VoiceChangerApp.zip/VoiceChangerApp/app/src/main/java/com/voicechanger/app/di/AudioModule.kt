package com.voicechanger.app.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Reserved for future providers that need explicit @Provides wiring (e.g. choosing which
 * AiVoiceModel implementation to bind based on a remote config flag or build variant).
 * AudioEngine and AiModelManager are constructor-injected directly, so nothing is required
 * here yet — kept as an explicit extension point per the requested module layout.
 */
@Module
@InstallIn(SingletonComponent::class)
object AudioModule
