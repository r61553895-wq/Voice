package com.voicechanger.app.presentation.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFBB86FC)
val PurplePrimary = Color(0xFF7C4DFF)
val PurpleDeep = Color(0xFF4A2FBF)
val BackgroundDark = Color(0xFF121016)
val SurfaceDark = Color(0xFF1E1B26)
val AccentCyan = Color(0xFF00E5FF)
val AccentPink = Color(0xFFFF4DA6)
val TextPrimary = Color(0xFFF5F3FA)
val TextSecondary = Color(0xFFA9A4B8)
