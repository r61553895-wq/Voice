package com.voicechanger.app.audio_engine.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.voicechanger.app.R
import com.voicechanger.app.audio_engine.AudioEngine
import com.voicechanger.app.domain.model.ProcessingMode
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Foreground service (type "microphone") so the voice changer keeps running when the app
 * is backgrounded or the screen is off, without Android killing the mic capture.
 */
@AndroidEntryPoint
class VoiceChangerService : Service() {

    @Inject lateinit var audioEngine: AudioEngine

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra(EXTRA_MODE)?.let { ProcessingMode.valueOf(it) }
            ?: ProcessingMode.DSP

        startForeground(NOTIFICATION_ID, buildNotification())
        audioEngine.setMode(mode)
        audioEngine.start()
        return START_STICKY
    }

    override fun onDestroy() {
        audioEngine.stop()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_running))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "voice_engine_channel"
        private const val NOTIFICATION_ID = 1001
        const val EXTRA_MODE = "extra_mode"
    }
}
