package com.voicechanger.app.ai_model

/** Passthrough "model" used for [com.voicechanger.app.domain.model.ProcessingMode.TEST_PASSTHROUGH]. */
class NoOpVoiceModel : AiVoiceModel {
    override val name: String = "NoOp / Passthrough"
    override val requiredSampleRate: Int = 48_000
    override val isRealtimeCapable: Boolean = true

    private var loaded = false

    override suspend fun load(modelPath: String): Boolean {
        loaded = true
        return true
    }

    override fun unload() {
        loaded = false
    }

    override fun convert(inputFrame: FloatArray): FloatArray = inputFrame

    override fun isLoaded(): Boolean = loaded
}
