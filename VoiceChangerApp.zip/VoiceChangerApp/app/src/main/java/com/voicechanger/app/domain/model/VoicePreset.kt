package com.voicechanger.app.domain.model

/**
 * Built-in voice presets. Each preset maps to a concrete [EffectSettings] configuration.
 * Presets are just "starting points" — the user can still fine-tune sliders afterwards.
 */
enum class VoicePreset(val displayName: String) {
    NORMAL("Normal"),
    DEEP("Deep"),
    FEMALE("Female"),
    ROBOT("Robot"),
    MONSTER("Monster"),
    ANIME("Anime");

    fun toDefaultSettings(): EffectSettings = when (this) {
        NORMAL -> EffectSettings(
            pitchSemitones = 0f,
            formant = 0f,
            speed = 1.0f,
            robotAmount = 0f,
            reverbMix = 0f,
            echoMix = 0f
        )
        DEEP -> EffectSettings(
            pitchSemitones = -6f,
            formant = -0.4f,
            speed = 1.0f,
            robotAmount = 0f,
            reverbMix = 0.15f,
            echoMix = 0f
        )
        FEMALE -> EffectSettings(
            pitchSemitones = 5f,
            formant = 0.35f,
            speed = 1.0f,
            robotAmount = 0f,
            reverbMix = 0.05f,
            echoMix = 0f
        )
        ROBOT -> EffectSettings(
            pitchSemitones = -1f,
            formant = 0f,
            speed = 1.0f,
            robotAmount = 0.85f,
            reverbMix = 0.1f,
            echoMix = 0.1f
        )
        MONSTER -> EffectSettings(
            pitchSemitones = -10f,
            formant = -0.6f,
            speed = 0.92f,
            robotAmount = 0.15f,
            reverbMix = 0.3f,
            echoMix = 0.15f
        )
        ANIME -> EffectSettings(
            pitchSemitones = 8f,
            formant = 0.5f,
            speed = 1.05f,
            robotAmount = 0f,
            reverbMix = 0.1f,
            echoMix = 0f
        )
    }
}
