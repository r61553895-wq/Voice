package com.voicechanger.app.domain.usecase

import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.repository.AudioEngineRepository
import javax.inject.Inject

class UpdateEffectSettingsUseCase @Inject constructor(
    private val repository: AudioEngineRepository
) {
    operator fun invoke(settings: EffectSettings) = repository.updateEffectSettings(settings)
}
