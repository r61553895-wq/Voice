package com.voicechanger.app.presentation.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.voicechanger.app.R
import com.voicechanger.app.domain.model.EngineState
import com.voicechanger.app.domain.model.ProcessingMode
import com.voicechanger.app.presentation.ui.components.EffectSlider
import com.voicechanger.app.presentation.ui.components.VoicePresetSelector
import com.voicechanger.app.presentation.viewmodel.VoiceChangerViewModel

@Composable
fun HomeScreen(
    micPermissionGranted: Boolean,
    onRequestMicPermission: () -> Unit,
    viewModel: VoiceChangerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Real-time voice transformation",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            item {
                PowerButton(
                    isRunning = uiState.isRunning,
                    micGranted = micPermissionGranted,
                    onToggle = {
                        if (!micPermissionGranted) onRequestMicPermission() else viewModel.onToggleEngine()
                    }
                )
            }

            item { EngineStatusBadge(uiState.engineState) }

            item {
                Text("Voice", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(10.dp))
                VoicePresetSelector(
                    selected = uiState.selectedPreset,
                    onSelect = viewModel::onSelectPreset
                )
            }

            item {
                Text("Processing engine", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(10.dp))
                ProcessingModeSelector(
                    selected = uiState.processingMode,
                    onSelect = viewModel::onProcessingModeChanged
                )
            }

            item {
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        EffectSlider(
                            label = "Pitch",
                            value = uiState.settings.pitchSemitones,
                            valueRange = -12f..12f,
                            valueLabel = "${"%+.1f".format(uiState.settings.pitchSemitones)} st",
                            onValueChange = viewModel::onPitchChanged
                        )
                        EffectSlider(
                            label = "Voice depth (formant)",
                            value = uiState.settings.formant,
                            valueRange = -1f..1f,
                            valueLabel = "%+.2f".format(uiState.settings.formant),
                            onValueChange = viewModel::onFormantChanged
                        )
                        EffectSlider(
                            label = "Speed",
                            value = uiState.settings.speed,
                            valueRange = 0.5f..1.5f,
                            valueLabel = "%.2fx".format(uiState.settings.speed),
                            onValueChange = viewModel::onSpeedChanged
                        )
                        EffectSlider(
                            label = "Reverb",
                            value = uiState.settings.reverbMix,
                            valueRange = 0f..1f,
                            valueLabel = "${(uiState.settings.reverbMix * 100).toInt()}%",
                            onValueChange = viewModel::onReverbChanged
                        )
                        EffectSlider(
                            label = "Echo",
                            value = uiState.settings.echoMix,
                            valueRange = 0f..1f,
                            valueLabel = "${(uiState.settings.echoMix * 100).toInt()}%",
                            onValueChange = viewModel::onEchoChanged
                        )
                    }
                }
            }

            if (!micPermissionGranted) {
                item {
                    Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                "Microphone permission required",
                                color = MaterialTheme.colorScheme.tertiary,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = onRequestMicPermission) {
                                Text("Grant permission")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PowerButton(isRunning: Boolean, micGranted: Boolean, onToggle: () -> Unit) {
    val gradient = Brush.radialGradient(
        colors = if (isRunning) {
            listOf(MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.primary)
        } else {
            listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.background)
        }
    )
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            modifier = Modifier
                .size(160.dp),
            onClick = onToggle,
            color = androidx.compose.ui.graphics.Color.Transparent
        ) {
            Box(
                modifier = Modifier.background(gradient, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Filled.Mic else Icons.Filled.MicOff,
                    contentDescription = if (isRunning) "Stop" else "Start",
                    tint = if (isRunning) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(56.dp)
                )
            }
        }
    }
}

@Composable
private fun EngineStatusBadge(state: EngineState) {
    val (text, color) = when (state) {
        is EngineState.Idle -> "Stopped" to MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        is EngineState.Starting -> "Starting…" to MaterialTheme.colorScheme.secondary
        is EngineState.Running -> "Live · ~${state.latencyMs}ms latency" to MaterialTheme.colorScheme.secondary
        is EngineState.Error -> "Error: ${state.message}" to MaterialTheme.colorScheme.error
    }
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Text(text = text, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ProcessingModeSelector(selected: ProcessingMode, onSelect: (ProcessingMode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProcessingMode.values().forEach { mode ->
                FilterChip(
                    selected = selected == mode,
                    onClick = { onSelect(mode) },
                    label = { Text(mode.label()) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }
        }
    }
}

private fun ProcessingMode.label(): String = when (this) {
    ProcessingMode.TEST_PASSTHROUGH -> "Test (no FX)"
    ProcessingMode.DSP -> "DSP"
    ProcessingMode.AI_MODEL -> "AI model"
}
