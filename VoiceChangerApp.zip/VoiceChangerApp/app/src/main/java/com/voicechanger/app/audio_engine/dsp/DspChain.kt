package com.voicechanger.app.audio_engine.dsp

import com.voicechanger.app.audio_engine.AudioConfig
import com.voicechanger.app.domain.model.EffectSettings
import kotlin.math.pow

/**
 * Signal chain order: pitch -> formant -> robot -> reverb -> echo -> speed(FIFO).
 * Pitch/formant/robot/reverb/echo all preserve frame length (1 sample in -> 1 sample out),
 * so they're processed directly on fixed-size frames. Speed is handled last via a small
 * FIFO because it changes the sample count (see [SpeedController]).
 */
class DspChain(
    sampleRate: Int = AudioConfig.SAMPLE_RATE,
    frameSize: Int = AudioConfig.FRAME_SIZE
) {
    private val pitchShifter = PitchShifter(AudioConfig.GRAIN_SIZE)
    private val formantShifter = FormantShifter(sampleRate)
    private val robotEffect = RobotEffect(sampleRate)
    private val reverbEffect = ReverbEffect(sampleRate)
    private val echoEffect = EchoEffect(sampleRate)
    val speedController = SpeedController(frameSize * 8)

    private val bufA = FloatArray(frameSize)
    private val bufB = FloatArray(frameSize)

    fun reset() {
        pitchShifter.reset()
        formantShifter.reset()
        robotEffect.reset()
        reverbEffect.reset()
        echoEffect.reset()
        speedController.reset()
    }

    /**
     * Processes one frame in place: [input] (raw mic float samples, -1..1) -> pushed into
     * the speed FIFO after DSP. Call [SpeedController.pop] separately to pull the
     * fixed-size frame that actually gets written to AudioTrack.
     */
    fun process(input: FloatArray, settings: EffectSettings) {
        val pitchRatio = 2.0.pow(settings.pitchSemitones / 12.0).toFloat()

        pitchShifter.process(input, bufA, pitchRatio)
        formantShifter.process(bufA, bufB, settings.formant)
        robotEffect.process(bufB, bufA, settings.robotAmount)
        reverbEffect.process(bufA, bufB, settings.reverbMix)
        echoEffect.process(bufB, bufA, settings.echoMix)

        speedController.push(bufA, settings.speed)
    }
}
