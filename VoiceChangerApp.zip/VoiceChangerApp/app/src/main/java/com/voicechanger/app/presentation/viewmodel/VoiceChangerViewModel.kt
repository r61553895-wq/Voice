package com.voicechanger.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicechanger.app.domain.model.EffectSettings
import com.voicechanger.app.domain.model.EngineState
import com.voicechanger.app.domain.model.ProcessingMode
import com.voicechanger.app.domain.model.VoicePreset
import com.voicechanger.app.domain.repository.AudioEngineRepository
import com.voicechanger.app.domain.usecase.SelectVoicePresetUseCase
import com.voicechanger.app.domain.usecase.StartVoiceChangerUseCase
import com.voicechanger.app.domain.usecase.StopVoiceChangerUseCase
import com.voicechanger.app.domain.usecase.UpdateEffectSettingsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import javax.inject.Inject

data class VoiceChangerUiState(
    val isRunning: Boolean = false,
    val selectedPreset: VoicePreset = VoicePreset.NORMAL,
    val settings: EffectSettings = EffectSettings(),
    val processingMode: ProcessingMode = ProcessingMode.DSP,
    val engineState: EngineState = EngineState.Idle
)

@HiltViewModel
class VoiceChangerViewModel @Inject constructor(
    private val repository: AudioEngineRepository,
    private val startUseCase: StartVoiceChangerUseCase,
    private val stopUseCase: StopVoiceChangerUseCase,
    private val updateEffectSettingsUseCase: UpdateEffectSettingsUseCase,
    private val selectVoicePresetUseCase: SelectVoicePresetUseCase
) : ViewModel() {

    private val _localState = MutableStateFlow(VoiceChangerUiState())

    val uiState: StateFlow<VoiceChangerUiState> = combine(
        _localState, repository.engineState
    ) { local, engineState ->
        local.copy(
            isRunning = engineState is EngineState.Running || engineState is EngineState.Starting,
            engineState = engineState
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VoiceChangerUiState())

    fun onToggleEngine() {
        val running = _localState.value.isRunning
        if (running) {
            stopUseCase()
        } else {
            startUseCase(_localState.value.processingMode)
        }
        _localState.update { it.copy(isRunning = !running) }
    }

    fun onSelectPreset(preset: VoicePreset) {
        val newSettings = selectVoicePresetUseCase(preset)
        _localState.update { it.copy(selectedPreset = preset, settings = newSettings) }
    }

    fun onPitchChanged(semitones: Float) {
        updateSettings { it.copy(pitchSemitones = semitones) }
    }

    fun onFormantChanged(formant: Float) {
        updateSettings { it.copy(formant = formant) }
    }

    fun onReverbChanged(mix: Float) {
        updateSettings { it.copy(reverbMix = mix) }
    }

    fun onEchoChanged(mix: Float) {
        updateSettings { it.copy(echoMix = mix) }
    }

    fun onSpeedChanged(speed: Float) {
        updateSettings { it.copy(speed = speed) }
    }

    fun onProcessingModeChanged(mode: ProcessingMode) {
        repository.setProcessingMode(mode)
        _localState.update { it.copy(processingMode = mode) }
    }

    private inline fun updateSettings(transform: (EffectSettings) -> EffectSettings) {
        val newSettings = transform(_localState.value.settings)
        updateEffectSettingsUseCase(newSettings)
        _localState.update { it.copy(settings = newSettings) }
    }

    override fun onCleared() {
        if (_localState.value.isRunning) stopUseCase()
        super.onCleared()
    }
}
