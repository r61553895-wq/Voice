package com.voicechanger.app.audio_engine.dsp

import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.PI

/**
 * Real-time pitch shifter based on the classic "dual-tap variable delay line" technique
 * (aka granular/OLA pitch shifting): two read pointers sweep through a circular buffer at
 * `pitchRatio` times the write rate, offset from each other by half a grain, and are
 * crossfaded with complementary Hann windows so the crossfade is power-preserving
 * (w1(d) + w1(d + N/2) == 1 for a raised-cosine window).
 *
 * This keeps output duration == input duration (no speed change) while shifting pitch by
 * `pitchRatio` (2.0 = +1 octave, 0.5 = -1 octave). It runs sample-by-sample so it can be
 * called on arbitrarily small blocks with no added structural latency beyond `grainSize`
 * samples (~10 ms at 48kHz with the default grain size) — well inside the <100ms budget.
 *
 * NOTE: this is a lightweight, dependency-free DSP technique, not a phase-vocoder or
 * AI model. Expect some artifacts on large shifts (>1 octave) or sustained vowels.
 * See ai_model/ for a path to swap in a neural voice-conversion model for higher quality.
 */
class PitchShifter(private val grainSize: Int) {

    private val bufSize = grainSize * 4
    private val buffer = FloatArray(bufSize)
    private var writeCount = 0L
    private var phase = 0f // "delay1" in samples, always in [0, grainSize)

    fun reset() {
        buffer.fill(0f)
        writeCount = 0
        phase = 0f
    }

    /**
     * Processes [input] in place order into [output] (same length). `pitchRatio` may change
     * between calls (e.g. live slider movement) without discontinuities.
     */
    fun process(input: FloatArray, output: FloatArray, pitchRatio: Float) {
        val alpha = pitchRatio.coerceIn(0.5f, 2.0f) // +/- 1 octave keeps quality reasonable
        val n = grainSize.toFloat()

        for (i in input.indices) {
            buffer[(writeCount % bufSize).toInt()] = input[i]
            writeCount++

            phase += (1f - alpha)
            if (phase < 0f) phase += n
            if (phase >= n) phase -= n

            var delay2 = phase + n / 2f
            if (delay2 >= n) delay2 -= n

            val w1 = 0.5f - 0.5f * cos((2.0 * PI * phase / n)).toFloat()
            val w2 = 0.5f - 0.5f * cos((2.0 * PI * delay2 / n)).toFloat()

            val s1 = readInterpolated(writeCount - 1L - phase)
            val s2 = readInterpolated(writeCount - 1L - delay2)

            output[i] = s1 * w1 + s2 * w2
        }
    }

    private fun readInterpolated(posFloat: Double): Float {
        if (posFloat < 0.0) return 0f
        val idx0 = floor(posFloat).toLong()
        val frac = (posFloat - idx0).toFloat()
        val i0 = floorMod(idx0, bufSize)
        val i1 = floorMod(idx0 + 1, bufSize)
        return buffer[i0] * (1 - frac) + buffer[i1] * frac
    }

    private fun floorMod(value: Long, m: Int): Int {
        val r = (value % m).toInt()
        return if (r < 0) r + m else r
    }
}
