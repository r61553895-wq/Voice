# Voice Changer — Real-Time AI Voice Changer (Android MVP)

Kotlin + Jetpack Compose Android app that captures the microphone in real time,
runs it through a DSP effects chain (pitch / formant / robot / reverb / echo / speed),
and plays it back with low latency. Architected so a real neural voice-conversion
model (RVC / ONNX / TFLite) can be dropped in without touching the UI or audio I/O code.

## 1. Project structure

```
app/src/main/java/com/voicechanger/app/
 ├── presentation/     Compose UI, ViewModel (MVVM)
 ├── domain/            Models, repository interface, use cases (pure Kotlin, no Android deps)
 ├── data/              Repository implementation (bridges domain <-> audio_engine)
 ├── audio_engine/      AudioRecord/AudioTrack loop, DSP chain, foreground service
 ├── ai_model/          AiVoiceModel interface + AiModelManager (the AI swap point)
 └── di/                Hilt modules
ai_model_templates/     ONNX / TFLite backend templates (not compiled by default)
```

Clean Architecture direction: `presentation -> domain <- data -> audio_engine/ai_model`.
`domain` has no Android imports — the use cases and models are plain Kotlin.

## 2. How to run it

### Option A — build in the cloud with GitHub Actions (no local install needed)

A ready-made workflow is included at `.github/workflows/build-apk.yml`. It builds a debug
APK on GitHub's servers and lets you download it — you only need a browser.

1. Extract this zip on your computer (built into Windows/macOS, no extra software).
2. Go to **github.com**, log in (or create a free account), click **New repository**
   (name it e.g. `voice-changer`), keep it **Public** or **Private**, click **Create repository**.
3. On the new repo's page, click **"uploading an existing file"** (or Add file → Upload files).
4. Drag the **entire extracted `VoiceChangerApp` folder** into the upload area (modern GitHub
   supports dropping whole folders, not just individual files) and click **Commit changes**.
5. Click the **Actions** tab at the top of the repo. GitHub will already be running
   "Build APK" (it triggers automatically on upload). Wait ~3–5 minutes.
6. Once it finishes (green checkmark), open that workflow run, scroll to **Artifacts**,
   and download **voice-changer-debug-apk** — that's a zip containing your installable `.apk`.
7. On your phone: unzip if needed, transfer the `.apk` to the phone (via cable, cloud drive,
   Telegram-to-self, etc.), tap it, allow "install from this source" if prompted, and install.

If a run fails, open the failed step's log — most first-run failures are one of:
missing/renamed files during upload, or a transient Android SDK license step (the workflow
accepts licenses automatically via `android-actions/setup-android`, but check the log if not).

### Option B — Android Studio (local)

1. Open the project root folder in **Android Studio (Koala/2024.1+)**.
2. Let it sync Gradle (uses AGP 8.3.2, Kotlin 1.9.24, compileSdk 34, minSdk 29).
   - If Android Studio asks to generate the Gradle wrapper jar, let it — it's not
     included as a binary in this delivery. Alternatively run `gradle wrapper --gradle-version 8.7`
     once you have any local Gradle install.
3. Run on a **physical device** running Android 10+ (real-time audio on emulators is
   unreliable — the emulator's virtual mic/speaker adds its own latency and often resamples).
4. On first launch, grant the microphone permission when prompted.
5. Tap the big mic button to start. Pick a preset (Normal/Deep/Female/Robot/Monster/Anime)
   or drag the sliders (Pitch, Voice depth, Speed, Reverb, Echo) live while it's running.
6. Use the **Processing engine** chips to switch between:
   - **Test (no FX)** — pure passthrough, use this first to confirm mic → speaker works
     and to measure baseline latency on your device.
   - **DSP** — the built-in effects chain (default).
   - **AI model** — routes through `AiModelManager`; falls back to DSP automatically until
     you've loaded a real model (see below), so it's always safe to tap.

**Wear headphones during testing** — playing the processed voice out of the phone's own
speaker while the mic is open will cause feedback/howling, same as any live mic+speaker setup.

## 3. Where to plug in a real AI voice-conversion model

Everything funnels through **`ai_model/AiModelManager.kt`** — that's the one file you edit:

1. Export/convert your model (RVC checkpoint, or any voice-conversion net) to **ONNX** or
   **TFLite**. For RVC specifically, community tools exist to export the generator to ONNX;
   you'll typically get a graph that expects a frame of audio (and often an F0/pitch
   contour + speaker embedding) and outputs the converted frame.
2. Copy the matching template:
   - `ai_model_templates/OnnxVoiceModel.kt.txt` → `app/src/main/java/.../ai_model/OnnxVoiceModel.kt`
   - or `ai_model_templates/TfliteVoiceModel.kt.txt` → `.../ai_model/TfliteVoiceModel.kt`
3. Uncomment the matching dependency in `app/build.gradle.kts`:
   ```kotlin
   implementation("com.microsoft.onnxruntime:onnxruntime-android:1.18.0")
   // or
   implementation("org.tensorflow:tensorflow-lite:2.16.1")
   ```
4. In `AiModelManager`, replace:
   ```kotlin
   private var currentModel: AiVoiceModel = NoOpVoiceModel()
   ```
   with your implementation, e.g. `OnnxVoiceModel(frameSize = AudioConfig.FRAME_SIZE)`.
5. Ship your model file in `assets/models/your_model.onnx` (or `.tflite`), copy it to
   `context.filesDir` on first run (Android can't `mmap` directly out of the APK's assets
   for most runtimes), and call `aiModelManager.loadModel(path)` — a natural place is right
   after the user selects "AI model" mode in the ViewModel.
6. Nothing in `audio_engine/AudioEngine.kt`, the ViewModel, or the UI needs to change —
   `ProcessingMode.AI_MODEL` already routes each mic frame through
   `AiModelManager.currentModel().convert(frame)` and falls back to the DSP chain if the
   model isn't loaded/ready yet.

**Real-time constraint to design around:** each mic frame is `AudioConfig.FRAME_SIZE`
samples (~20 ms @ 48 kHz). Your model's inference time per frame must stay well under
that budget on-device (aim for <10 ms so there's headroom), or you'll hear glitches/underruns.
Most RVC-class models are too heavy to run frame-by-frame on a phone CPU today without
quantization (INT8) and a larger analysis hop with internal buffering — this is why
`isRealtimeCapable` exists on `AiVoiceModel`: report `false` honestly and the engine will
keep using DSP instead of stuttering.

## 4. How to improve voice quality

- **Formant accuracy**: the current `FormantShifter` is a cheap EQ-based approximation.
  For real formant-preserving pitch shift, implement LPC analysis/synthesis (estimate
  vocal-tract filter coefficients, flatten the spectral envelope, pitch-shift the residual,
  then reapply a warped envelope) — or just replace this stage with an AI model, which is
  exactly what neural voice conversion is good at.
- **Pitch shifter artifacts**: `PitchShifter` uses a dependency-free dual-tap delay-line
  technique. For higher fidelity, swap it for a proper phase vocoder (FFT-based, preserves
  transients better) or a battle-tested library like **SoundTouch** or **Rubberband**
  (both have Android/NDK ports) — or **Sonic** (small, MIT-licensed, made for exactly this).
- **Echo cancellation / noise**: `AudioRecord` is already opened with
  `MediaRecorder.AudioSource.VOICE_COMMUNICATION`, which lets the device apply its built-in
  AEC/NS/AGC where available. You can also explicitly enable `AcousticEchoCanceler` and
  `NoiseSuppressor` (`android.media.audiofx`) if supported on the target device.
- **Sample rate**: 48 kHz mono is used throughout; dropping to 16/24 kHz reduces CPU cost
  if you need more headroom for a heavier AI model, at some cost to brightness/clarity.
- **True lowest latency**: for the tightest possible round-trip, port the audio I/O loop to
  **Oboe** (Google's C++ low-latency audio library) over NDK instead of the plain Java
  AudioRecord/AudioTrack APIs used here — see section 5.

## 5. Path to a system-wide virtual microphone

Right now the app only feeds its own speaker/headphone output — other apps (Zoom, Discord,
games) can't "see" the processed voice as a mic input. To get there:

1. **VoIP/communication apps that support it**: on Android there's no public, official
   "virtual microphone" API third-party apps automatically pick up — that would need OS-level
   support Android doesn't currently expose to normal apps.
2. **Practical route — a virtual audio HAL/loopback via root or a custom ROM module**: tools
   like Magisk modules or custom audio policy XML can create a loopback device, but this
   requires root and is fragile across OEM skins/Android versions — not viable for a
   general-audience app on the Play Store.
3. **App-to-app routing without root**: implement an `AudioPlaybackCapture`-based approach
   in reverse isn't applicable here (that API captures *other* apps' output, not feeds a mic).
   The realistic non-root approach is a **Bluetooth/USB virtual audio device**: expose the
   processed stream as a Bluetooth A2DP/HFP sink other apps can select as their audio input,
   or ship a companion **desktop app** (Windows/Mac) with a real virtual-mic driver
   (e.g. via VB-Cable-style kernel driver) and stream the phone's processed audio to it over
   USB/Wi-Fi — this is how most commercial "voice changer for Discord" products actually work.
4. **Android 14+ `AudioMixerAttributes` / Enterprise MDM routes**: some enterprise/OEM builds
   allow registering privileged audio policies, but that's not available to regular Play
   Store apps either.

Realistic roadmap: ship the in-app experience first (this MVP), then build a companion
desktop virtual-audio-cable app and a low-latency phone↔desktop streaming bridge (e.g. over
a local WebSocket/RTP connection) as a v2 feature, rather than trying to register a system
mic directly from the Android app.

## 6. Performance notes already built in

- Audio loop runs on its own thread at `THREAD_PRIORITY_URGENT_AUDIO`, not on Compose/main.
- `AudioTrack` uses `PERFORMANCE_MODE_LOW_LATENCY` (API 26+) and matches the device's
  minimum buffer sizes rather than over-buffering.
- `VOICE_COMMUNICATION` audio source/usage reduce OS-level processing overhead and enable
  hardware AEC/NS where the device supports it.
- Foreground service (`android:foregroundServiceType="microphone"`) keeps the engine alive
  when the screen is off or the app is backgrounded, without the OS killing the mic session.
- All DSP is fixed-size, allocation-free per sample in the hot loop (buffers are pre-allocated
  once in `DspChain`/`AudioEngine`), avoiding GC pauses that would show up as audio glitches.

## 7. Known limitations of this MVP (by design, to keep it dependency-free and buildable as-is)

- DSP quality is "good enough to demo," not studio-grade — see section 4 for upgrade paths.
- No NDK/C++ engine is wired in by default (kept the build simple); the note in
  `app/build.gradle.kts` shows where to re-enable `externalNativeBuild` + Oboe if you want to
  port the hot loop to C++ for the last few ms of latency.
- AI model paths are templates, not a bundled model — you provide the `.onnx`/`.tflite` file.
